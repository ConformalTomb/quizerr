<?php
session_start(); /* Session */
$con=mysqli_connect("localhost","id3328626_quizerr","quizzing","id3328626_quizerr"); /*Database Connection*/
?>
