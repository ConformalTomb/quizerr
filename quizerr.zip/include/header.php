<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Quizerr-The quiz making app!!</title>
    <!-- Include CSS -->
    <link href="./css/bootstrap.min.css" rel="stylesheet"><!-- Bootstrap CSS -->
    <link href="./css/style.css" rel="stylesheet"><!-- Custom CSS -->
    <!-- Include Google font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,300,600">
</head>
<body>