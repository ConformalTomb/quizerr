<div class="footer">
<hr>
<h6>This shit is brought to you by Kunal Pahwa because his girlfriend is too busy attending classes on a fucking SUNDAY...</h6>
<h6>ain't got copyrights so feel free to steal what is already stolen!</h6>
</div>

<!-- Include JavaScripts -->
<script src="./js/jquery.min.js"></script><!-- Load jquery -->
<script src="./js/bootstrap.min.js"></script><!-- Load bootstrap js -->
<script src="./js/app.js"></script><!-- Load custom js -->

</body>
</html>
